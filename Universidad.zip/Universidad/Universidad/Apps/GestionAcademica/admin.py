from django.contrib import admin
from Universidad.Apps.GestionAcademica.models import *
# Register your models here.

admin.site.register(Alumno)
admin.site.register(Curso)
admin.site.register(Matricula)